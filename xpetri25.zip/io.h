#ifndef __IO__
#define __IO__
#include <stdio.h>

int read_word(char *s, int max, FILE *f);

#endif